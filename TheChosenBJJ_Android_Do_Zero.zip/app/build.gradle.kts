plugins { id("com.android.application") }
android {
 namespace = "br.com.thechosenbjj"
 compileSdk = 35
 defaultConfig { applicationId = "br.com.thechosenbjj"; minSdk = 24; targetSdk = 35; versionCode = 2; versionName = "1.1" }
 compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
}
