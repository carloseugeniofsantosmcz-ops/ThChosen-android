package br.com.thechosenbjj;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.net.Uri;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebChromeClient;
import android.webkit.ValueCallback;
import android.webkit.WebSettings;

public class MainActivity extends Activity {
 private static final String APP_URL = "https://teal-rabanadas-efb0fd.netlify.app/";
 private WebView web;
 private ValueCallback<Uri[]> upload;
 private static final int FILE_PICKER = 1001;
 @Override public void onCreate(Bundle savedInstanceState) {
  super.onCreate(savedInstanceState);
  web = new WebView(this);
  WebSettings settings = web.getSettings();
  settings.setJavaScriptEnabled(true);
  settings.setDomStorageEnabled(true);
  settings.setAllowFileAccess(false);
  settings.setAllowContentAccess(true);
  settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
  web.setWebViewClient(new WebViewClient() {
   @Override public boolean shouldOverrideUrlLoading(WebView view, android.webkit.WebResourceRequest request) {
    Uri uri = request.getUrl();
    if ("https".equals(uri.getScheme()) && "teal-rabanadas-efb0fd.netlify.app".equals(uri.getHost())) return false;
    if ("http".equals(uri.getScheme()) || "https".equals(uri.getScheme()) || "mailto".equals(uri.getScheme()) || "tel".equals(uri.getScheme())) {
     try { startActivity(new Intent(Intent.ACTION_VIEW, uri)); } catch (Exception ignored) {}
     return true;
    }
    return false;
   }
  });
  web.setWebChromeClient(new WebChromeClient() {
   @Override public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
    if (upload != null) upload.onReceiveValue(null);
    upload = callback;
    try { startActivityForResult(params.createIntent(), FILE_PICKER); return true; }
    catch (Exception e) { upload = null; callback.onReceiveValue(null); return false; }
   }
  });
  setContentView(web);
  web.loadUrl(APP_URL);
 }
 @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
  super.onActivityResult(requestCode, resultCode, data);
  if (requestCode == FILE_PICKER && upload != null) {
   upload.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(resultCode, data));
   upload = null;
  }
 }
 @Override public void onBackPressed() {
  if (web.canGoBack()) web.goBack(); else super.onBackPressed();
 }
 @Override protected void onDestroy() { if (web != null) web.destroy(); super.onDestroy(); }
}
