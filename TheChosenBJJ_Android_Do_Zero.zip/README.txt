THE CHOSEN BJJ — PROJETO ANDROID 1.1

Este ZIP é um projeto Android Studio, NÃO é um APK pronto.

Para compilar no computador:
1. Instale Android Studio (com SDK Android 35 e JDK 17).
2. Extraia o ZIP e abra a pasta TheChosenBJJ_Android_Atualizado.
3. Aguarde a sincronização do Gradle.
4. Menu Build > Build Bundle(s) / APK(s) > Build APK(s).
5. O arquivo instalável será gerado em app/build/outputs/apk/debug/app-debug.apk.

O app usa WebView para carregar a versão publicada em:
https://teal-rabanadas-efb0fd.netlify.app/

O site precisa estar público e acessível. O app depende de conexão com a internet. A atualização do site no Netlify aparece também no aplicativo Android.

O projeto suporta JavaScript, armazenamento local, envio de arquivos/comprovantes e navegação HTTPS. Ainda não foi compilado nem testado em dispositivo real neste ambiente.
